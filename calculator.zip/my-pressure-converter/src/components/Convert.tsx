import React, { useState } from 'react';

const units = {
  psi: 6894.76,
  bar: 100000,
  pascal: 1,
};

export default function Converter() {
  const [value, setValue] = useState('');
  const [fromUnit, setFromUnit] = useState('psi');
  const [toUnit, setToUnit] = useState('bar');
  const [result, setResult] = useState<number | null>(null);

  const convert = () => {
    const num = parseFloat(value);
    if (isNaN(num)) return;

    const inPascals = num * units[fromUnit as keyof typeof units];
    const converted = inPascals / units[toUnit as keyof typeof units];

    setResult(converted);

    const history = JSON.parse(localStorage.getItem('pressure-history') || '[]');
    history.unshift({
      id: Date.now(),
      from: `${value} ${fromUnit}`,
      to: `${converted.toFixed(4)} ${toUnit}`,
    });
    localStorage.setItem('pressure-history', JSON.stringify(history));
  };

  return (
    <div>
      <h2>Конвертер давления</h2>
      <input
        type="number"
        placeholder="Введите значение"
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <select value={fromUnit} onChange={(e) => setFromUnit(e.target.value)}>
        <option value="psi">PSI</option>
        <option value="bar">Бар</option>
        <option value="pascal">Паскаль</option>
      </select>
      <select value={toUnit} onChange={(e) => setToUnit(e.target.value)}>
        <option value="psi">PSI</option>
        <option value="bar">Бар</option>
        <option value="pascal">Паскаль</option>
      </select>
      <button onClick={convert}>Конвертировать</button>
      {result !== null && <p>Результат: {result.toFixed(4)} {toUnit}</p>}
    </div>
  );
}