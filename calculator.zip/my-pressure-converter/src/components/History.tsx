import React, { useEffect, useState } from 'react';

interface HistoryEntry {
  id: number;
  from: string;
  to: string;
}

export default function History() {
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('pressure-history') || '[]');
    setHistory(data);
  }, []);

  const clearHistory = () => {
    localStorage.removeItem('pressure-history');
    setHistory([]);
  };

  return (
    <div>
      <h2>История конверсий</h2>
      {history.length === 0 ? (
        <p>Нет записей</p>
      ) : (
        <ul>
          {history.map((entry) => (
            <li key={entry.id}>{entry.from} → {entry.to}</li>
          ))}
        </ul>
      )}
      <button onClick={clearHistory}>Очистить историю</button>
    </div>
  );
}