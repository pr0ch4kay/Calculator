import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Converter from './components/Convert';
import History from './components/History';
import './styles/global.scss';

export default function App() {
  return (
    <Router>
      <div className="container">
        <nav>
          <Link to="/">Конвертер</Link> | <Link to="/history">История</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Converter />} />
          <Route path="/history" element={<History />} />
        </Routes>
      </div>
    </Router>
  );
}